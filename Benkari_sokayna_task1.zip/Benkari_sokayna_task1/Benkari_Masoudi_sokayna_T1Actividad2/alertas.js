
//1 El primer mensaje debe mostrar la suma de 2 variables numéricas cuyo valor sea 15 y 26 respectivamente. 
let num1 = 15;
let num2 = 26;
let suma = num1 + num2;
alert(suma);

//2 El segundo mensaje debe mostrar la suma de 2 variables una en formato cadena y la otra en formato numérico (se reutilizará del punto anterior). El valor de ambas variables debe ser el mismo que el del punto anterior.
let num3 = "15";
let num4 = 26;
let suma2 = num3 + num4;
alert(suma2);

//3 El tercer mensaje debe mostrar el tipo de formato la variable string creada previamente.
alert(typeof num3);