  
  const meses = [
       "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
       ];
    for (let i = 0; i < meses.length; i++) {
          alert(meses[i]);
                i++;
        }