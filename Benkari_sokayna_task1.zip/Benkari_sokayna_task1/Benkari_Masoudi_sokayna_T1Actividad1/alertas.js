        //El primer mensaje debe mostrar el mensaje de alerta “Hola mundo”.
        alert("Hola mundo");

        //El segundo mensaje debe mostrar una constante que se haya definido con vuestro nombre completo (Nombre + Apellido1 + Apellido2).
        const alumna = "Sokayna Benkari Masoudi";
        alert(alumna);

        //El tercer mensaje debe mostrar que el comando alert es realmente una función específica de javascript.
        alert(typeof alert);
